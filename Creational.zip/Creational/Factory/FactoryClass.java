package DesignPattern.Creational.Factory;

/**
 * Real World use cases:
 * 1. GUI libraries where each operating system provides a different implementation of a button or a window.
 *
 * 2. E-commerce platforms offer multiple payment gateways, where each gateway has a different process.
 *
 * 3. Database connection pools where connections to different types of databases need to be created based on configuration.
 */
interface Drink{
    void prepare();
}

class Coffee implements Drink{

    @Override
    public void prepare(){
        System.out.println("Coffee prepare.");
    }
}

class Tea implements Drink{

    @Override
    public void prepare(){
        System.out.println("Tea prepare.");
    }
}

class DrinkFactory{

    public Drink getDrink(String drinkType){
        if(drinkType == null){
            return null;
        }
        if(drinkType.equalsIgnoreCase("COFFEE")){
            return new Coffee();
        }
        else if(drinkType.equalsIgnoreCase("TEA")){
            return new Tea();
        }

        return null;
    }
}

public class FactoryClass {
    public static void main(String[] args) {
        DrinkFactory drinkFactory = new DrinkFactory();

        Drink drink1 = drinkFactory.getDrink("COFFEE");
        drink1.prepare();

        Drink drink2 = drinkFactory.getDrink("TEA");
        drink2.prepare();

    }
}
