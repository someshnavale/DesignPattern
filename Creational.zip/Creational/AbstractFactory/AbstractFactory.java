package DesignPattern.Creational.AbstractFactory;

/**
 * 4. Real-World Use Cases
 * 1. GUI libraries where different themes or OS have distinct looks and behaviors for components.
 *
 * 2. E-commerce platforms where different regions require different combinations of payment gateways, tax calculations, and shipping rules.
 *
 * 3. Game development where different environments (forest, desert, underwater) might have different sets of characters, obstacles, and backgrounds
 */

interface Button{
    void click();
}
interface TextBox{
    void type();
}

class DarkButton implements Button{

    @Override
    public void click() {
        System.out.println("Dark button clicked ");
    }
}

class LightButton implements Button{
    @Override
    public void click(){
        System.out.println("Light button clicked.");
    }
}

class DarkTextbox implements TextBox{
    @Override
    public void type(){
        System.out.println("Dark text boxed typed.");
    }
}

class LightTextBox implements TextBox{

    @Override
    public void type(){
        System.out.println("Light text boxed typed.");
    }
}

interface GUIFactory{
    Button createButton();
    TextBox createTextBox();

}

class DarkThemeFactory implements GUIFactory{

    @Override
    public Button createButton(){
        return new DarkButton();
    }
    @Override
    public TextBox createTextBox(){
        return new DarkTextbox();
    }
}

class LightThemFactory implements GUIFactory{

    @Override
    public Button createButton(){
        return new LightButton();
    }

    @Override
    public TextBox createTextBox(){
        return new LightTextBox();
    }
}
public class AbstractFactory {

    public static void main(String[] args) {
        GUIFactory factory = new DarkThemeFactory();
        Button button = factory.createButton();
        TextBox textBox = factory.createTextBox();

        button.click();
        textBox.type();

        factory = new LightThemFactory();
        button = factory.createButton();
        textBox = factory.createTextBox();

        button.click();
        textBox.type();
    }
}
