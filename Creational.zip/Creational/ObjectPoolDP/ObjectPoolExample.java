package DesignPattern.Creational.ObjectPoolDP;

import java.util.ArrayList;
import java.util.List;

/**
 * 4. Real-World Use Cases
 * 1. Connection pools where establishing a connection is costly and time-consuming.
 *
 * 2. Thread pools for executing concurrent tasks without the overhead of continuously creating and destroying threads.
 *
 * 3. Reusing large graphics objects like bitmaps in a game.
 */

class PooledObject{
    private String data;

    public PooledObject(String data){
        this.data = data;
    }

    public String getData(){
        return data;
    }
}

class ObjectPool{
        private List<PooledObject> available = new ArrayList<>();
        private List<PooledObject> inUse = new ArrayList<>();

        public PooledObject acquire(){
            if(available.isEmpty()){
                available.add(new PooledObject("New Object"));
            }
            PooledObject obj = available.remove(0);
            inUse.add(obj);
            return obj;
        }
        public void release(PooledObject obj){
            inUse.remove(obj);
            available.add(obj);
        }
}

//client
public class ObjectPoolExample {
    public static void main(String[] args) {
        ObjectPool objPool = new ObjectPool();
        PooledObject obj1 = objPool.acquire();
        System.out.println(obj1.getData());

        objPool.release(obj1);
        PooledObject obj2 = objPool.acquire();
        System.out.println(obj2.getData());
    }

}
