package DesignPattern.Creational.Prototype;

/**
 * 4. Real-World Use Cases
 * 1. Cloning/copying configurations or settings for different modules in software.
 * <p>
 * 2. Creating unique instances of objects that have most of their state consistent but differ slightly.
 * <p>
 * 3. In gaming, duplicating existing game objects or characters.
 */

//Step 1: create prototype interface
interface Prototype {
    Prototype clone();
}

// Implement prototype interface in concrete class
class ConcreatePrototype implements Prototype{

    private String attribute;

    public ConcreatePrototype(String attribute){
        this.attribute = attribute;
    }

    public String getAttribute(){
        return attribute;
    }

    @Override
    public Prototype clone(){
        return new ConcreatePrototype(this.attribute);
    }

    @Override
    public String toString(){
        return  "Attribute: "+attribute;
    }
}

//Demonstrations
public class PrototypeExample {

    public static void main(String[] args) {
       ConcreatePrototype original = new ConcreatePrototype("Initival object value");
       ConcreatePrototype cloned = (ConcreatePrototype) original.clone();

        System.out.println("Original Object:  "+original);
        System.out.println("Clonedc Object: "+cloned);
    }

}
