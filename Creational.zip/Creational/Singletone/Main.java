package DesignPattern.Creational.Singletone;

public class Main {
    public static void main(String[] args) {
        Singletone singletone = Singletone.getInstance();
        singletone.log("singletone pattern impl...!");
    }
}
