package DesignPattern.Creational.Singletone;

/**
 * Logging / Login SignUp functionality
 */
public class Singletone {

    private static Singletone instance; //Single instance of class
    private static final Object lock = new Object();

    private Singletone(){
        // private constructor to prevent obj creation from outside
    }
    public static Singletone getInstance(){
        if(instance == null){
            synchronized (lock){
                if(instance == null){
                    instance = new Singletone();
                }
            }
        }
        return instance;
    }
    //Add method specific to your singletone class
    public void log(String message){
        System.out.println("Your log message is :"+message);
    }

}
