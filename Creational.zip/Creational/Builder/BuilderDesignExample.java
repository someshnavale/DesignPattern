package DesignPattern.Creational.Builder;

/**
 * 4. Real-World Use Cases
 * 1. Constructing complex meal sets in fast-food restaurants.
 *
 * 2. Building detailed and customizable characters in video games.
 *
 * 3. Crafting tailored travel packages in booking systems with multiple elements like flights, hotels, and tours.
 */

// Step:1 create product class
class Car{
    private String engine;
    private String wheel;
    private String color;

    public void setEngine(String engine) {
        this.engine = engine;
    }

    public void setWheel(String wheel) {
        this.wheel = wheel;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return "BuilderDesignExample{" +
                "engine='" + engine + '\'' +
                ", wheel='" + wheel + '\'' +
                ", color='" + color + '\'' +
                '}';
    }
}

//Create the builder interface
interface CarBuilder{

    void buildEngine();
    void buildWheel();
    void buildColor();

    Car getCar();
}

//Step: 3 Implement the sprot car builder

class SportCarBuilder implements CarBuilder{

    private Car car = new Car();

    @Override
    public void buildEngine(){
        car.setEngine("Sport Engine");
    }
    @Override
    public void buildWheel(){
        car.setWheel("Racing wheel");
    }

    @Override
    public void buildColor(){
        car.setColor("Red");
    }

    @Override
    public Car getCar(){
        return car;
    }

}

// Implement the Family car builder
class FamilyCarBuilder implements CarBuilder{
    private Car car = new Car();

    @Override
    public void buildEngine(){
        car.setEngine("Family Engine");
    }
    @Override
    public void buildWheel(){
        car.setWheel("Family wheel");
    }
    @Override
    public void buildColor(){
        car.setColor("White");
    }
    @Override
    public Car getCar(){
        return car;
    }
}

//Step 4: Define a director class
class CarDirector{
    private CarBuilder builder;

    public CarDirector(CarBuilder builder){
        this.builder = builder;
    }
    public Car construct(){
        builder.buildEngine();
        builder.buildWheel();
        builder.buildColor();
        return builder.getCar();
    }

}

// Demostration
public class BuilderDesignExample {

    public static void main(String[] args) {
        CarBuilder sportCarBuilder = new SportCarBuilder();
        CarDirector director = new CarDirector(sportCarBuilder);

        Car car = director.construct();
        System.out.println(car);

        CarBuilder familyCarBuilder = new FamilyCarBuilder();
        CarDirector director1 = new CarDirector(familyCarBuilder);

        Car car2 = director1.construct();
        System.out.println(car2);
    }
}
